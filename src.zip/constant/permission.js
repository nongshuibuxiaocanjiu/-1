export default {
  employees: {
    add: 'employees-add',
    import: 'employees-import',
    del: 'employees-del',
  },
  roles: {
    add: 'roles-add',
    edit: 'roles-edit',
  },
}
