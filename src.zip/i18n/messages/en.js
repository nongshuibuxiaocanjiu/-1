export default {
  name: 'English',
  dashboard: {
    work: 'work',
  },
}
