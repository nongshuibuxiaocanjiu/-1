export default {
  name:'中文',
  dashboard: {
    work: '工作经历',
  },
}
