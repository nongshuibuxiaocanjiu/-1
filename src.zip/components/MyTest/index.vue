<template>
  <div>测试组件</div>
</template>

<script>
export default {
  name: 'MyTest',
  data() {
    return {}
  },

  created() {},

  methods: {},
}
</script>

<style scoped lang="less"></style>
